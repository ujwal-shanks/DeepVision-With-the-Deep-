import matplotlib.pyplot as plt
import numpy as np

x = np.array([4, 7, 8, 10])
y = np.array([2, 14, 10, 16])

plt.plot(x, y)
plt.show()